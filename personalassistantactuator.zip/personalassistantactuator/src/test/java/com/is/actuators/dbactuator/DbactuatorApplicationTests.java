package com.is.actuators.dbactuator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbactuatorApplicationTests {

    @Test
    void contextLoads() {
    }


}
