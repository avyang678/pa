$(document).ready(function() {
    fetchData();
});

function fetchData() {
    var url = "categories";
    ajaxRequest(url, "GET", "", firstTimeLoad);
}

function firstTimeLoad(response) {
    renderData(response);
}

function createFormInOrder(data) {
    colss = data.COLUMNS;
    categoryName = data.categoryName;
    categoryId = data.categoryId;
    var formString = "";
    for (var j = 0; j < data.COLUMNS.length; j++) {
        if ("categoryFormDataId" === colss[j]) {
            formString = formString + '<div class="form-group col-md-2"> <input type="text" class="form-control" id="textInput_' + data.COLUMNS[j] + '" placeholder="' + data.COLUMNS[j] + '" readonly="readonly" " >  </div>';
        } else {
            formString = formString + '<div class="form-group col-md-2"> <input type="text" class="form-control" id="textInput_' + data.COLUMNS[j] + '" placeholder="' + data.COLUMNS[j] + '" >  </div>';
        }
    }
    $("#dynamicForm").append(formString);
}


function tableRowClicked(tableID, identifier) {
    var table = $("#" + tableID).DataTable();
    var selectedTableRowData = table.rows('.selected').data();

    $("#categoryId").val(selectedTableRowData[0][0]);
    $("#categoryName").val(selectedTableRowData[0][1]);
    $("#categoryDesc").val(selectedTableRowData[0][2]);

}

function updateData() {
    var url = "categories/";
    var requestData = getRequestedInputData();
    console.log("++++++===" + requestData)
    ajaxRequest(url, "POST", requestData, updateDataResponseHandler);
}

function updateDataResponseHandler(response) {
    renderData(response);
    clearData();
}

function deleteData() {
    var url = "categories/" + $("#categoryId").val();;
    ajaxRequest(url, "DELETE", '', deleteDataResponseHandler);
}

function cloneData() {
    $("#categoryId").val("");
}
function refreshData() {
   fetchData();
}
function clearData() {
    $("#categoryId").val("");
    $("#categoryName").val("");
    $("#categoryDesc").val("");
}

function getRequestedInputData() {
    categoryFormDataObject = {};
    categoryFormDataObject["categoryId"] = parseInt($("#categoryId").val());;
    categoryFormDataObject["categoryName"] = $("#categoryName").val();
    categoryFormDataObject["categoryDesc"] = $("#categoryDesc").val();
    return JSON.stringify(categoryFormDataObject);
}