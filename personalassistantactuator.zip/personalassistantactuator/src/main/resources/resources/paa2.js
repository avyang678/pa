$(document).ready(function() {
    fetchData();
});

function fetchData() {
    var url1 = "categories";
    ajaxRequest(url1, "GET", "", categoriesHandler);
}

function firstTimeLoad(response) {
    renderData(response);
}

function categoriesHandler(response) {
 clearData();
    createFormInOrder(response);


}

function createFormInOrder(data) {
    var formString = '<select class="form-control" id="categoryList" onchange="categoryChanged()"> <option value="0" > Select Any Category</option>';
    for (var j = 0; j < data.ROWS.length; j++) {
        formString = formString + '<option value="' + data.ROWS[j][0] + '">' + data.ROWS[j][1] + '  </option>';
    }
    $("#categoryBoxList").append(formString + "</select>");
}

function categoryChanged() {
clearData();
    var url = "categoriesForms/" + $("#categoryList").val();
     $("#categoryId").val($("#categoryList").val());
    ajaxRequest(url, "GET", "", firstTimeLoad);
}

function tableRowClicked(tableID, identifier) {
    var table = $("#" + tableID).DataTable();
    var selectedTableRowData = table.rows('.selected').data();

  /*  $("#categoryId").val(selectedTableRowData[0][0]);*/
    $("#categoryFormId").val(selectedTableRowData[0][0]);
    $("#categoryFormName").val(selectedTableRowData[0][1]);
    $("#categoryFormNameDesc").val(selectedTableRowData[0][2]);

}

function updateData() {
    var url = "categoriesForms/";
    var requestData = getRequestedInputData();
    console.log("++++++===" + requestData)
    ajaxRequest(url, "POST", requestData, updateDataResponseHandler);
}

function updateDataResponseHandler(response) {
    renderData(response);
    clearData();
}

function deleteData() {
    var url = "categoriesForms/" + $("#categoryFormId").val();;
    ajaxRequest(url, "DELETE", '', deleteDataResponseHandler);
}

function cloneData() {
    $("#categoryFormId").val("");
}
function refreshData() {
   categoryChanged()
}
function clearData() {
/* $("#categoryId").val("");*/
console.log("ccccccccccccccccccccccccccccc")
    $("#categoryFormId").val("");
    $("#categoryFormName").val("");
    $("#categoryFormNameDesc").val("");
}

function getRequestedInputData() {
    categoryFormDataObject = {};
     categoryFormDataObject["categoryId"] = parseInt($("#categoryId").val());
    categoryFormDataObject["categoryFormId"] = parseInt($("#categoryFormId").val());;
    categoryFormDataObject["categoryFormName"] = $("#categoryFormName").val();
    categoryFormDataObject["categoryFormNameDesc"] = $("#categoryFormNameDesc").val();
    return JSON.stringify(categoryFormDataObject);
}