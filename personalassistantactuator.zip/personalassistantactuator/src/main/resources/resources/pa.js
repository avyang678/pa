var colss;
var categoryId;
var categoryName;

$(document).ready(function() {
    fetchData();
});

function fetchData() {
    //http://localhost:8084/dbactuator/allCategoriesData
    var url1 = "categories";
    ajaxRequest(url1, "GET", "", categoriesHandler);
}

function categoriesHandler(response) {
    createFormInOrderqqq(response);
}

function createFormInOrderqqq(data) {

        var formString = '<select class="form-control" id="categoryList" onchange="categoryChanged()"> <option value="0" > Select Any Category</option>';
        for (var j = 0; j < data.ROWS.length; j++) {
            formString = formString + '<option value="' + data.ROWS[j][0] + '">' + data.ROWS[j][1] + '  </option>';
        }
        $("#categoryBoxList").append(formString + "</select>");

}

function categoryChanged() {
    var url = "categoriesFormData/" + $("#categoryList").val();
    categoryId = $("#categoryList").val();

    ajaxRequest(url, "GET", "", firstTimeLoad);
}

function firstTimeLoad(response) {
console.log("DD CALL RES::::"+JSON.stringify(response))
 if (response.COLUMNS.length>0) {
   createFormInOrder(response);
   renderData(response);
}else{
console.log("DD CALL RES:: 0 clear table");
  $("#dynamicForm").html("");
 $("#groupList").html("");

 getFormFieldForSelectedCategory();
 //http://localhost:8084/dbactuator/categoriesForms/2
}



}
function getFormFieldForSelectedCategory(response) {
    var url1 = "categoriesForms/labels/" + $("#categoryList").val();
       ajaxRequest(url1, "GET", "", formFieldForSelectedCategoryHandler);
}

function formFieldForSelectedCategoryHandler(response) {
 $("#dynamicForm").html("");
 $("#groupList").html("");
console.log("DD CALL RES::::"+JSON.stringify(response));
    createFormInOrder(response);
    //  renderData(response);
}


function deleteDataResponseHandler(response) {
    renderData(response);
    clearData();
}

function createFormInOrder(data) {
    colss = data.COLUMNS;
    categoryName = data.categoryName;
    categoryId = data.categoryId;
    var formString = "";
    for (var j = 0; j < data.COLUMNS.length; j++) {
        if ("categoryFormDataId" === colss[j]) {
            formString = formString + '<div class="form-group col-md-2"> <input type="text" class="form-control" id="textInput_' + data.COLUMNS[j] + '" placeholder="' + data.COLUMNS[j] + '" readonly="readonly" " >  </div>';
        } else {
            formString = formString + '<div class="form-group col-md-2"> <input type="text" class="form-control" id="textInput_' + data.COLUMNS[j] + '" placeholder="' + data.COLUMNS[j] + '" >  </div>';
        }
    }
    $("#dynamicForm").html("");
    $("#dynamicForm").append(formString);
}

function tableRowClicked(tableID, identifier) {
    var table = $("#" + tableID).DataTable();
    var selectedTableRowData = table.rows('.selected').data();
    //	console.log(JSON.stringify(selectedTableRowData))
    for (var j = 0; j < selectedTableRowData[0].length; j++) {
        $("#textInput_" + colss[j]).val(selectedTableRowData[0][j]);
    }

}

function updateData() {
    var url = "categoriesFormData/";
    var requestData = getRequestedInputData();
    console.log("++++++===" + requestData)
    ajaxRequest(url, "POST", requestData, updateDataResponseHandler);
}

function updateDataResponseHandler(response) {
    renderData(response);
    clearData();
}

function deleteData() {
    for (var j = 0; j < colss.length; j++) {
        if ("categoryFormDataId" === colss[j]) {
            categoryFormDataId = $("#textInput_" + colss[j]).val()
        }
    }
    var url = "categoriesFormData/" + $("#categoryList").val() +"/"+ categoryFormDataId;
    ajaxRequest(url, "DELETE", '', deleteDataResponseHandler);
}

function cloneData() {
    for (var j = 0; j < colss.length; j++) {
        if ("categoryFormDataId" === colss[j]) {
            $("#textInput_" + colss[j]).val("")
        }
    }
}

function clearData() {
    for (var j = 0; j < colss.length; j++) {
        $("#textInput_" + colss[j]).val("");
    }
}
function refreshData() {
   categoryChanged()
}

function getRequestedInputData() {
    var categoryFormDataId;
    categoryFormData = {};
    for (var j = 0; j < colss.length; j++) {
        if ("categoryFormDataId" === colss[j]) {
            categoryFormDataId = $("#textInput_" + colss[j]).val()
        } else {
            categoryFormData[colss[j]] = $("#textInput_" + colss[j]).val();
        }
    }
    categoryFormDataObject = {};
    categoryFormDataObject["categoryName"] = categoryName;
    categoryFormDataObject["categoryId"] = $("#categoryList").val();
    categoryFormDataObject["categoryFormDataId"] = parseInt(categoryFormDataId);

    categoryFormDataObject["categoryFormData"] = categoryFormData

    console.log("############### " + categoryFormDataObject["categoryId"])
    return JSON.stringify(categoryFormDataObject);
}