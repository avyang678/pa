package com.is.actuators.dbactuator.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.is.actuators.dbactuator.model.CategoryFormData;
import com.is.actuators.dbactuator.service.CategoryFromDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@Slf4j
public class PACategoryFormDataController {

    @Autowired
    private CategoryFromDataService categoryFromDataService;

    @GetMapping("/categoriesFormData")
    public Map<String, Object> getEnvs() throws JsonProcessingException {
        Long startTime = System.currentTimeMillis();

        Map<String, Object> result = new HashMap<>();
        List<CategoryFormData> categoryFormData = categoryFromDataService.allFOrmData();

        List<String> cols = new ArrayList<>();
        cols.add("categoryFormDataId");
        List<List<String>> rows = new ArrayList<>();
        boolean columnsToBeAddedinList = true;
        for (CategoryFormData formData : categoryFormData) {
            List<String> row = new ArrayList<>();
            row.add("" + formData.getCategoryFormDataId());

            Map<String, String> response = new ObjectMapper().readValue(formData.getCategoryFormData(), LinkedHashMap.class);
            for (Map.Entry entry : response.entrySet()) {
                if (columnsToBeAddedinList) {
                    cols.add("" + entry.getKey());

                    result.put("categoryName", formData.getCategoryName());
                    result.put("categoryId", formData.getCategoryId());

                }

                row.add("" + entry.getValue());

            }
            rows.add(row);
            columnsToBeAddedinList = false;
        }

        result.put("ROWS", rows);
        result.put("COLUMNS", cols);


        return result;
    }


    @GetMapping("/categoriesFormData/{categoryId}")
    public Map<String, Object> getEndddvs(@PathVariable Long categoryId ) throws JsonProcessingException {
        Long startTime = System.currentTimeMillis();

        Map<String, Object> result = new HashMap<>();
        List<CategoryFormData> categoryFormData = categoryFromDataService.getallFormDataByCtegoryId(categoryId);

        List<String> cols = new ArrayList<>();
        if(categoryFormData.size()>0){
            cols.add("categoryFormDataId");
        }

//        cols.add("categoryName");
        List<List<String>> rows = new ArrayList<>();
        boolean columnsToBeAddedinList = true;
        for (CategoryFormData formData : categoryFormData) {
            List<String> row = new ArrayList<>();
            row.add("" + formData.getCategoryFormDataId());

            Map<String, String> response = new ObjectMapper().readValue(formData.getCategoryFormData(), LinkedHashMap.class);
            for (Map.Entry entry : response.entrySet()) {
                if (columnsToBeAddedinList) {
                    cols.add("" + entry.getKey());

                    result.put("categoryName", formData.getCategoryName());
                    result.put("categoryId", formData.getCategoryId());

                }

                row.add("" + entry.getValue());

            }
            rows.add(row);
            columnsToBeAddedinList = false;
        }

        result.put("ROWS", rows);
        result.put("COLUMNS", cols);


        return result;
    }

    @RequestMapping(value = "/categoriesFormData", method = RequestMethod.POST)
    @ResponseBody
    public Object updateConfiguration(@RequestBody Map<String, Object> map) throws JsonProcessingException {
        CategoryFormData categoryFormDat1a = new CategoryFormData();
        Map<String, Object> response = new HashMap<>();
        String aaa = new ObjectMapper().writeValueAsString(map.get("categoryFormData"));
        categoryFormDat1a.setCategoryName(map.get("categoryName") + "");
        categoryFormDat1a.setCategoryId(Long.parseLong(map.get("categoryId") + ""));
        if (null != map.get("categoryFormDataId")) {
            categoryFormDat1a.setCategoryFormDataId(Long.parseLong(map.get("categoryFormDataId") + ""));
            response.put("MSG", "Record Updated successfully");
        } else {
            response.put("MSG", "Record Created successfully");
        }

        categoryFormDat1a.setCategoryFormData(aaa);
        CategoryFormData categoryFormData = categoryFromDataService.updateMe(categoryFormDat1a);

        response.putAll(getEndddvs(categoryFormDat1a.getCategoryId()));

        return response;
    }

    @RequestMapping(value = "/categoriesFormData/{categoryId}/{categoryFormDataId}", method = RequestMethod.DELETE)
    @ResponseBody
    public Object removeConfiguration(@PathVariable("categoryId") Long categoryId, @PathVariable("categoryFormDataId") Long categoryFormDataId) throws JsonProcessingException {
        Map<String, Object> response = new HashMap<>();
        categoryFromDataService.deleteMe(Long.parseLong(categoryFormDataId+""));
        response.putAll(getEndddvs(categoryId));
        response.put("MSG", "Record deleted successfully");
        return response;
    }

}
