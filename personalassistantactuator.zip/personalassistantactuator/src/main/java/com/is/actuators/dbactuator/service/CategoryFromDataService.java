package com.is.actuators.dbactuator.service;

import com.is.actuators.dbactuator.model.CategoryForm;
import com.is.actuators.dbactuator.model.CategoryFormData;
import com.is.actuators.dbactuator.repository.CategoryFormDataRepository;
import com.is.actuators.dbactuator.repository.CategoryFormRepository;
import com.is.actuators.dbactuator.repository.CategoryRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class CategoryFromDataService {


    @Autowired
    private CategoryFormDataRepository categoryFormDataRepository;

    public List<CategoryFormData> allCategoriesForAdmin() {
        return categoryFormDataRepository.findAll();
    }
    public List<CategoryFormData> allFOrmData() {
        return categoryFormDataRepository.findAll();
    }

    public List<CategoryFormData> getallFormDataByCtegoryId(Long categoryId) {
        return categoryFormDataRepository.getallFormDataByCtegoryId(categoryId);
    }

    public CategoryFormData updateMe(CategoryFormData categoryFormData) {

        return categoryFormDataRepository.saveAndFlush(categoryFormData);
    }

    public void deleteMe(Long aLong) {
          categoryFormDataRepository.deleteById(aLong);
    }

    public CategoryFormData getCategoryFormData() {
        return null;
    }

}
