package com.is.actuators.dbactuator.model;

import com.fasterxml.jackson.annotation.JsonView;
import com.is.actuators.dbactuator.view.ApiView;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "PA_CATEGORY_FORM_DATA")
public class CategoryFormData extends BaseModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonView(ApiView.Public.class)
    private Long categoryFormDataId;
    @JsonView(ApiView.Admin.class)
    private Long categoryId;

    @JsonView(ApiView.Admin.class)
    private String categoryName;
    private String categoryFormData;


}
