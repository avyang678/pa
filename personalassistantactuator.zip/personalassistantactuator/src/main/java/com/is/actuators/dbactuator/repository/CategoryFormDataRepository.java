package com.is.actuators.dbactuator.repository;

import com.is.actuators.dbactuator.model.CategoryForm;
import com.is.actuators.dbactuator.model.CategoryFormData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Repository
public interface CategoryFormDataRepository extends JpaRepository<CategoryFormData, Long> {


    @Query("SELECT t FROM CategoryFormData t WHERE t.categoryId = ?1 ")
    List<CategoryFormData> getallFormDataByCtegoryId(Long categoryId);

    @Modifying
    @Transactional
    @Query("UPDATE  CategoryFormData set categoryFormData =:categoryFormData WHERE categoryFormDataId =:categoryFormDataId")
    void updateCategoryDataFormRows(@Param("categoryFormData") String categoryFormData, @Param("categoryFormDataId") Long categoryFormDataId);

    @Modifying
    @Transactional
    @Query("UPDATE  CategoryFormData set categoryName =:categoryName WHERE categoryId =:categoryId")
    void updateCategoryName(@Param("categoryName") String categoryName, @Param("categoryId") Long categoryId);


//    @Modifying
//    @Transactional
//    @Query("UPDATE  CategoryFormData set categoryName =?1 WHERE categoryId =?2 ")
//    void updateCategoryNamess(String categoryName, Long categoryId);
}




