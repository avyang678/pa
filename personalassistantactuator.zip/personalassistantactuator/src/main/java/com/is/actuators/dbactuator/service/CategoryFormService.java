package com.is.actuators.dbactuator.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.is.actuators.dbactuator.model.CategoryForm;
import com.is.actuators.dbactuator.model.CategoryFormData;
import com.is.actuators.dbactuator.repository.CategoryFormDataRepository;
import com.is.actuators.dbactuator.repository.CategoryFormRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class CategoryFormService {

    @Autowired
    private CategoryFormRepository categoryFormRepository;
    @Autowired
    private CategoryFormDataRepository categoryFormDataRepository;

    public List<CategoryForm> findAll() {
        return categoryFormRepository.findAll();
    }

    public List<CategoryForm> allFOrmData() {
        return categoryFormRepository.findAll();
    }

    public List<CategoryForm> getallFormDataByCtegoryId(Long categoryId) {
        return categoryFormRepository.getallFormDataByCtegoryId(categoryId);
    }


    public CategoryForm updateMe(CategoryForm categoryFormData) {
        List<CategoryFormData> allrows = categoryFormDataRepository.getallFormDataByCtegoryId(categoryFormData.getCategoryId());
        CategoryForm dbCategoryForm = null;

        if (categoryFormData.getCategoryFormId() != null) {
            dbCategoryForm = categoryFormRepository.findById(categoryFormData.getCategoryFormId()).get();
        }

        for (CategoryFormData formData : allrows) {
            Map<String, String> updateRow = new LinkedHashMap<>();
            String oldData = formData.getCategoryFormData();
            Map<String, String> response = null;
            try {
                response = new ObjectMapper().readValue(formData.getCategoryFormData(), LinkedHashMap.class);
                //checking data json map
                for (Map.Entry<String, String> entry : response.entrySet()) {
                    if (dbCategoryForm != null && entry.getKey().equals(dbCategoryForm.getCategoryFormName())) {
                        updateRow.put(categoryFormData.getCategoryFormName(), entry.getValue());
                    } else {
                        updateRow.put(entry.getKey(), entry.getValue());
                    }

                }
                if (dbCategoryForm == null) {
                    updateRow.put(categoryFormData.getCategoryFormName(), " ");
                }
                // update record in db
                response = new ObjectMapper().readValue(formData.getCategoryFormData(), LinkedHashMap.class);
                System.out.println("old=" + oldData);
                String aaa = new ObjectMapper().writeValueAsString(updateRow);
                System.out.println("new=" + aaa);
                categoryFormDataRepository.updateCategoryDataFormRows(aaa, formData.getCategoryFormDataId());


            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }


        }


        return categoryFormRepository.saveAndFlush(categoryFormData);
    }

    public void deleteMe(Long aLong) {
        categoryFormRepository.deleteById(aLong);
    }


}
