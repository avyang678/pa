package com.is.actuators.dbactuator.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.is.actuators.dbactuator.model.Category;
import com.is.actuators.dbactuator.model.CategoryFormData;
import com.is.actuators.dbactuator.service.CategoryFormService;
import com.is.actuators.dbactuator.service.CategoryFromDataService;
import com.is.actuators.dbactuator.service.CategoryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController


@Slf4j
public class PACategoryController {
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private CategoryFromDataService categoryFromDataService;

    @Autowired
    private CategoryFormService categoryFormService;

    @GetMapping("/categories")
    public Map<String, Object> getEnvs() throws JsonProcessingException {
        Long startTime = System.currentTimeMillis();

        Map<String, Object> result = new HashMap<>();
        List<Category> categoryFormData = categoryService.allFOrmData();

        List<String> cols = new ArrayList<>();
        cols.add("CategoryId");
        cols.add("CategoryName");
        cols.add("CategoryDesc");
        List<List<String>> rows = new ArrayList<>();
        boolean columnsToBeAddedinList = true;
        for (Category formData : categoryFormData) {
            List<String> row = new ArrayList<>();
            row.add("" + formData.getCategoryId());
            row.add("" + formData.getCategoryName());
            row.add("" + formData.getCategoryDesc());
            rows.add(row);

        }

        result.put("ROWS", rows);
        result.put("COLUMNS", cols);


        return result;
    }

    @RequestMapping(value = "/categories", method = RequestMethod.POST)
    @ResponseBody
    public Object updateConfiguration(@RequestBody Category map) throws JsonProcessingException {
        CategoryFormData categoryFormDat1a = new CategoryFormData();
        Map<String, Object> response = new HashMap<>();

        if (null != map.getCategoryId()) {
            categoryFormDat1a.setCategoryFormDataId(Long.parseLong(map.getCategoryId() + ""));
            response.put("MSG", "Record Updated successfully");
        } else {
            response.put("MSG", "Record Created successfully");
        }

       categoryService.updateMe(map);

        response.putAll(getEnvs());

        return response;
    }

    @RequestMapping(value = "/categories/{categoryFormDataId}", method = RequestMethod.DELETE)
    @ResponseBody
    public Object removeConfiguration(@PathVariable("categoryFormDataId") String categoryId) throws JsonProcessingException {
        Map<String, Object> response = new HashMap<>();
        categoryService.deleteMe(Long.parseLong(categoryId));
        response.putAll(getEnvs());
        response.put("MSG", "Record deleted successfully");
        return response;
    }







}
