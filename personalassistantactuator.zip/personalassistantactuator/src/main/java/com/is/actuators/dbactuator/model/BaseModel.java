package com.is.actuators.dbactuator.model;

import com.fasterxml.jackson.annotation.JsonView;
import com.is.actuators.dbactuator.view.ApiView;

import javax.persistence.MappedSuperclass;
import java.util.Date;

@MappedSuperclass
public class BaseModel {
    @JsonView(ApiView.Admin.class)
    private Boolean isActive;

    @JsonView(ApiView.Audit.class)
    private String createdBy;
    @JsonView(ApiView.Audit.class)
    private String modifiedBy;
    @JsonView(ApiView.Audit.class)
    private Date createdDt;
    @JsonView(ApiView.Audit.class)
    private Date modifiedDt;

}
