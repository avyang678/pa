package com.is.actuators.dbactuator.view;

public class ApiView {
    public static class Public {
    }

    public static class Admin extends Public {
    }

    public static class Audit extends Admin {
    }
}
