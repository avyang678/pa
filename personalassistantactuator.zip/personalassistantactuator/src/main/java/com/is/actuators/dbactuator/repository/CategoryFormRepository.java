package com.is.actuators.dbactuator.repository;

import com.is.actuators.dbactuator.model.CategoryForm;
import com.is.actuators.dbactuator.model.CategoryFormData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface CategoryFormRepository extends JpaRepository<CategoryForm, Long>{
    @Query("SELECT t FROM CategoryForm t WHERE t.categoryId = ?1 ")
    List<CategoryForm> getallFormDataByCtegoryId(Long categoryId);
    @Modifying(clearAutomatically = true)
    @Query("UPDATE  CategoryForm set categoryName =:categoryName WHERE categoryId =:categoryId")
    List<CategoryForm> getallFormDataByCtegoryId(@Param("categoryName") Long categoryName, @Param("categoryId") Long categoryId);

}


