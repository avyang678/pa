package com.is.actuators.dbactuator.service;

import com.is.actuators.dbactuator.model.Category;
import com.is.actuators.dbactuator.model.CategoryFormData;
import com.is.actuators.dbactuator.repository.CategoryFormDataRepository;
import com.is.actuators.dbactuator.repository.CategoryRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class CategoryService {


    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private CategoryFormDataRepository categoryFormDataRepository ;

    public List<Category> allCategoriesForAdmin() {
        return categoryRepository.findAll();
    }
    public List<Category> allFOrmData() {
        return categoryRepository.findAll();
    }


    public Category updateMe(Category categoryFormData) {

        // update in form data table
       // categoryFormDataRepository.updateCategoryNamess(categoryFormData.getCategoryName(), categoryFormData.getCategoryId());
        //   @Transactional  important when we modify ant=y records
        categoryFormDataRepository.updateCategoryName(categoryFormData.getCategoryName(), categoryFormData.getCategoryId());
        return categoryRepository.saveAndFlush(categoryFormData);
    }

    public void deleteMe(Long aLong) {
        categoryRepository.deleteById(aLong);
    }


}
