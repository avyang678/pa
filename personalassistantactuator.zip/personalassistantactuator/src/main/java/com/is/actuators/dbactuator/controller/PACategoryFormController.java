package com.is.actuators.dbactuator.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.is.actuators.dbactuator.model.Category;
import com.is.actuators.dbactuator.model.CategoryForm;
import com.is.actuators.dbactuator.model.CategoryFormData;
import com.is.actuators.dbactuator.service.CategoryFormService;
import com.is.actuators.dbactuator.service.CategoryFromDataService;
import com.is.actuators.dbactuator.service.CategoryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController


@Slf4j
public class PACategoryFormController {
    ;
    @Autowired
    private CategoryFormService categoryFormService;



    @GetMapping("/categoriesForms")
    public Map<String, Object> getEnvs() throws JsonProcessingException {

        Map<String, Object> result = new HashMap<>();
        List<CategoryForm> categoryFormData = categoryFormService.allFOrmData();

        List<String> cols = new ArrayList<>();
        cols.add("CategoryFormId");
        cols.add("CategoryFormName");
        cols.add("CategoryFormNameDesc");
        List<List<String>> rows = new ArrayList<>();
        boolean columnsToBeAddedinList = true;
        for (CategoryForm formData : categoryFormData) {
            List<String> row = new ArrayList<>();
            row.add("" + formData.getCategoryFormId() );
            row.add("" + formData.getCategoryFormName());
            row.add("" + formData.getCategoryFormNameDesc());
            rows.add(row);

        }

        result.put("ROWS", rows);
        result.put("COLUMNS", cols);


        return result;
    }

    @GetMapping("/categoriesForms/labels/{categoryId}")
    public Map<String, Object> sseeeeeeeeesss(@PathVariable Long categoryId) throws JsonProcessingException {
        List<CategoryForm> categoryFormData = categoryFormService.getallFormDataByCtegoryId(categoryId);

        Map<String, Object> result = new HashMap<>();

        List<String> cols = new ArrayList<>();

        for (CategoryForm categoryForm: categoryFormData ){
            cols.add(categoryForm.getCategoryFormName());
        }


        //result.put("ROWS", rows);
        result.put("COLUMNS", cols);
        return result;
    }

    @GetMapping("/categoriesForms/{categoryId}")
    public Map<String, Object> sssss(@PathVariable Long categoryId) throws JsonProcessingException {
        Map<String, Object> result = new HashMap<>();
        List<CategoryForm> categoryFormData = categoryFormService.getallFormDataByCtegoryId(categoryId);

        List<String> cols = new ArrayList<>();

      /*  cols.add("categoryId");*/
        cols.add("CategoryFormId");
        cols.add("CategoryFormName");
        cols.add("CategoryFormNameDesc");
        List<List<String>> rows = new ArrayList<>();
        boolean columnsToBeAddedinList = true;
        for (CategoryForm formData : categoryFormData) {
            List<String> row = new ArrayList<>();
         /*   row.add("" + formData.getCategoryId() );*/
            row.add("" + formData.getCategoryFormId() );
            row.add("" + formData.getCategoryFormName());
            row.add("" + formData.getCategoryFormNameDesc());
            rows.add(row);

        }

        result.put("ROWS", rows);
        result.put("COLUMNS", cols);


        return result;
    }



    @RequestMapping(value = "/categoriesForms", method = RequestMethod.POST)
    @ResponseBody
    public Object updateConfiguration(@RequestBody CategoryForm map) throws JsonProcessingException {
        //public Object updateConfiguration(@RequestBody Map<String, Object> map) throws JsonProcessingException {

        Map<String, Object> response = new HashMap<>();

        if (null != map.getCategoryFormId()) {

            response.put("MSG", "Record Updated successfully");
        } else {
            response.put("MSG", "Record Created successfully");
        }

        CategoryForm categoryFormData = categoryFormService.updateMe(map);

        response.putAll(sssss(map.getCategoryId()));

        return response;
    }

    @RequestMapping(value = "/categoriesForms/{categoryFormDataId}", method = RequestMethod.DELETE)
    @ResponseBody
    public Object removeConfiguration(@PathVariable("categoryFormDataId") String categoryId) throws JsonProcessingException {
        Map<String, Object> response = new HashMap<>();
        categoryFormService.deleteMe(Long.parseLong(categoryId));
        response.putAll(getEnvs());
        response.put("MSG", "Record deleted successfully");
        return response;
    }


}
